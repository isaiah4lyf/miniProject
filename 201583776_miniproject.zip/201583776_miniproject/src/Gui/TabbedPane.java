package Gui;

import javax.swing.JTabbedPane;

public class TabbedPane extends JTabbedPane{
	public TabbedPane()
	{
		
	}
	
}
